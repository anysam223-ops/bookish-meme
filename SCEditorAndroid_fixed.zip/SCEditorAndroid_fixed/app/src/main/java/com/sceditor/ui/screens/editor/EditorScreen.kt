package com.sceditor.ui.screens.editor

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sceditor.data.model.*
import com.sceditor.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    fileUri: String,
    exportId: Int,
    onNavigateBack: () -> Unit,
    vm: EditorViewModel = hiltViewModel()
) {
    LaunchedEffect(fileUri, exportId) { vm.load(fileUri, exportId) }
    val state by vm.state.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // SAF save dialog
    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? -> uri?.let { vm.saveToUri(it.toString()) } }

    // Observe save/error feedback
    LaunchedEffect(state.isSaved) {
        if (state.isSaved) {
            scope.launch { snackbarHostState.showSnackbar("File saved successfully") }
        }
    }
    LaunchedEffect(state.error) {
        state.error?.let { err ->
            scope.launch { snackbarHostState.showSnackbar("Error: $err") }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        state.export?.name ?: "Editor",
                        color = OnDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, null, tint = OnDark)
                    }
                },
                actions = {
                    IconButton(onClick = { vm.cloneExport() }) {
                        Icon(Icons.Default.CopyAll, "Clone export", tint = AccentBlue)
                    }
                    IconButton(onClick = {
                        val fileName = fileUri.substringAfterLast("/")
                            .substringAfterLast("%2F")
                            .ifEmpty { "output.sc" }
                        saveLauncher.launch(fileName)
                    }) {
                        Icon(Icons.Default.Save, "Save", tint = AccentYellow)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        if (state.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), Alignment.Center) {
                CircularProgressIndicator(color = AccentYellow)
            }
            return@Scaffold
        }

        val mc = state.movieclip ?: run {
            Box(Modifier.fillMaxSize().padding(padding), Alignment.Center) {
                Text("Export not found in file", color = AccentRed)
            }
            return@Scaffold
        }

        Column(Modifier.fillMaxSize().padding(padding)) {

            FrameSelector(
                frames        = mc.frames,
                selectedIndex = state.selectedFrameIndex,
                onSelect      = { vm.selectFrame(it) },
                onAdd         = { vm.addFrame() },
                onRemove      = { vm.removeFrame() }
            )

            HorizontalDivider(color = DarkCard)

            val frame = mc.frames.getOrNull(state.selectedFrameIndex)
            if (frame != null) {
                ElementList(
                    elements      = frame.elements,
                    selectedIndex = state.selectedElementIndex,
                    scFile        = state.scFile,
                    onSelect      = { vm.selectElement(it) }
                )
            } else {
                Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.VideoFile, null, tint = OnDarkSecondary,
                            modifier = Modifier.size(48.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("No frames yet", color = OnDarkSecondary)
                        Text("Tap + to add a frame", color = OnDarkSecondary,
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            if (state.selectedElementIndex >= 0) {
                PositionControls(onMove = { dx, dy -> vm.moveElement(dx, dy) })
            }
        }
    }
}

@Composable
private fun FrameSelector(
    frames: List<MovieclipFrame>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    onAdd: () -> Unit,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("FRAMES", style = MaterialTheme.typography.labelSmall,
            color = OnDarkSecondary, modifier = Modifier.padding(end = 8.dp))

        LazyRow(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            itemsIndexed(frames) { idx, frame ->
                val selected = idx == selectedIndex
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (selected) AccentYellow else DarkCard)
                        .border(1.dp,
                            if (selected) AccentYellow else DarkCard,
                            RoundedCornerShape(6.dp))
                        .clickable { onSelect(idx) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text     = frame.name.ifEmpty { "#$idx" },
                        style    = MaterialTheme.typography.bodySmall,
                        color    = if (selected) DarkBackground else OnDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        IconButton(onClick = onAdd, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Default.Add, "Add frame", tint = AccentYellow)
        }
        IconButton(
            onClick  = onRemove,
            enabled  = frames.isNotEmpty(),
            modifier = Modifier.size(36.dp)
        ) {
            Icon(Icons.Default.Remove, "Remove frame",
                tint = if (frames.isNotEmpty()) AccentRed else OnDarkSecondary)
        }
    }
}

@Composable
private fun ElementList(
    elements: List<FrameElement>,
    selectedIndex: Int,
    scFile: ScFile?,
    onSelect: (Int) -> Unit
) {
    LazyColumn(
        modifier = Modifier.weight(1f),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (elements.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) {
                    Text("This frame has no elements", color = OnDarkSecondary)
                }
            }
        }
        itemsIndexed(elements) { idx, el ->
            val selected  = idx == selectedIndex
            val shapeInfo = scFile?.shapes?.find { it.id == el.shapeId }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) DarkCard else DarkSurface)
                    .border(1.dp,
                        if (selected) AccentBlue else DarkCard,
                        RoundedCornerShape(8.dp))
                    .clickable { onSelect(idx) }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Layers, null,
                    tint = if (selected) AccentBlue else OnDarkSecondary,
                    modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Shape #${el.shapeId}  (${shapeInfo?.chunks?.size ?: "?"} chunks)",
                        color = OnDark, style = MaterialTheme.typography.titleMedium)
                    Text("Matrix: ${el.matrixIndex}  |  ColorSpace: ${el.colorSpaceIndex}",
                        style = MaterialTheme.typography.bodySmall, color = OnDarkSecondary)
                }
            }
        }
    }
}

@Composable
private fun PositionControls(onMove: (Float, Float) -> Unit) {
    var dxText by remember { mutableStateOf("0") }
    var dyText by remember { mutableStateOf("0") }

    Surface(color = DarkSurface, tonalElevation = 4.dp) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text("LIVE POSITION EDIT", style = MaterialTheme.typography.labelSmall,
                color = OnDarkSecondary)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value         = dxText,
                    onValueChange = { dxText = it },
                    label         = { Text("Δ X") },
                    modifier      = Modifier.weight(1f),
                    singleLine    = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor   = AccentYellow,
                        unfocusedBorderColor = DarkCard,
                        focusedLabelColor    = AccentYellow,
                        cursorColor          = AccentYellow,
                        focusedTextColor     = OnDark,
                        unfocusedTextColor   = OnDark
                    )
                )
                OutlinedTextField(
                    value         = dyText,
                    onValueChange = { dyText = it },
                    label         = { Text("Δ Y") },
                    modifier      = Modifier.weight(1f),
                    singleLine    = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor   = AccentYellow,
                        unfocusedBorderColor = DarkCard,
                        focusedLabelColor    = AccentYellow,
                        cursorColor          = AccentYellow,
                        focusedTextColor     = OnDark,
                        unfocusedTextColor   = OnDark
                    )
                )
                Button(
                    onClick = {
                        val dx = dxText.toFloatOrNull() ?: 0f
                        val dy = dyText.toFloatOrNull() ?: 0f
                        onMove(dx, dy)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AccentYellow,
                        contentColor   = DarkBackground
                    )
                ) {
                    Icon(Icons.Default.Check, null)
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                DPadControls(onMove)
            }
        }
    }
}

@Composable
private fun DPadControls(onMove: (Float, Float) -> Unit) {
    val step = 5f
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = { onMove(0f, -step) }) {
            Icon(Icons.Default.KeyboardArrowUp, "Up", tint = AccentBlue)
        }
        Row {
            IconButton(onClick = { onMove(-step, 0f) }) {
                Icon(Icons.Default.KeyboardArrowLeft, "Left", tint = AccentBlue)
            }
            Spacer(Modifier.size(40.dp))
            IconButton(onClick = { onMove(step, 0f) }) {
                Icon(Icons.Default.KeyboardArrowRight, "Right", tint = AccentBlue)
            }
        }
        IconButton(onClick = { onMove(0f, step) }) {
            Icon(Icons.Default.KeyboardArrowDown, "Down", tint = AccentBlue)
        }
    }
}
