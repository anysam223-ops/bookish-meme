package com.sceditor.data.repository

import com.sceditor.data.model.*

/**
 * Merges exports from a [source] SC file into a [base] SC file.
 *
 * Equivalent to the "Combine 2 SC Files" feature in the desktop editor:
 *  - Imports selected exports and their full dependency trees (shapes, matrices, colorspaces).
 *  - Remaps IDs to avoid collisions with the base file.
 *  - Optionally reuses existing objects from the base file by specifying [shapeIdRemaps].
 */
object ScFileCombiner {

    /**
     * @param base          The file to import into
     * @param source        The file to import from
     * @param exportIds     IDs of exports in [source] to import
     * @param shapeIdRemaps Map of sourceShapeId → baseShapeId to reuse existing shapes
     */
    fun combine(
        base: ScFile,
        source: ScFile,
        exportIds: List<Int>,
        shapeIdRemaps: Map<Int, Int> = emptyMap()
    ): ScFile {
        val newExports     = base.exports.toMutableList()
        val newMovieclips  = base.movieclips.toMutableList()
        val newShapes      = base.shapes.toMutableList()
        val newTextures    = base.textures.toMutableList()
        val newMatrices    = base.matrices.toMutableList()
        val newColorSpaces = base.colorSpaces.toMutableList()

        // --- ID offsets so we don't collide with base ---
        val movieclipIdOffset  = (base.movieclips.maxOfOrNull { it.id } ?: 0) + 1
        val shapeIdOffset      = (base.shapes.maxOfOrNull { it.id } ?: 0) + 1
        val textureIndexOffset = base.textures.size
        val matrixOffset       = base.matrices.size
        val colorSpaceOffset   = base.colorSpaces.size

        // Collect exports to import from source
        val sourceExports = source.exports.filter { it.id in exportIds }

        // Gather all referenced movieclip IDs recursively
        val mcIds = mutableSetOf<Int>()
        sourceExports.forEach { collectMovieclipIds(it.movieclipId, source, mcIds) }

        // Gather all referenced shape IDs
        val shapeIds = mutableSetOf<Int>()
        mcIds.forEach { mcId ->
            source.movieclips.find { it.id == mcId }?.frames?.forEach { frame ->
                frame.elements.forEach { shapeIds.add(it.shapeId) }
            }
        }

        // Add textures (full copy if whole texture not already present)
        val textureIndexMap = mutableMapOf<Int, Int>()
        source.textures.forEachIndexed { srcIdx, tex ->
            val newIdx = newTextures.size
            newTextures.add(tex.copy(index = newIdx))
            textureIndexMap[srcIdx] = newIdx
        }

        // Add shapes (skip remapped ones)
        val shapeIdMap = shapeIdRemaps.toMutableMap()
        shapeIds.filter { it !in shapeIdRemaps }.forEach { srcShapeId ->
            val srcShape = source.shapes.find { it.id == srcShapeId } ?: return@forEach
            val newId = srcShape.id + shapeIdOffset
            val newChunks = srcShape.chunks.map { chunk ->
                chunk.copy(textureIndex = textureIndexMap[chunk.textureIndex] ?: chunk.textureIndex)
            }.toMutableList()
            newShapes.add(Shape(newId, newChunks))
            shapeIdMap[srcShapeId] = newId
        }

        // Add matrices
        val matrixIdMap = mutableMapOf<Int, Int>()
        source.matrices.forEachIndexed { i, m ->
            matrixIdMap[i] = newMatrices.size
            newMatrices.add(m.copy(id = newMatrices.size))
        }

        // Add color spaces
        val csIdMap = mutableMapOf<Int, Int>()
        source.colorSpaces.forEachIndexed { i, cs ->
            csIdMap[i] = newColorSpaces.size
            newColorSpaces.add(cs.copy(id = newColorSpaces.size))
        }

        // Add movieclips (remap IDs)
        val mcIdMap = mutableMapOf<Int, Int>()
        mcIds.forEach { srcMcId ->
            val srcMc = source.movieclips.find { it.id == srcMcId } ?: return@forEach
            val newMcId = srcMc.id + movieclipIdOffset
            mcIdMap[srcMcId] = newMcId
            val newFrames = srcMc.frames.map { frame ->
                val newElements = frame.elements.map { el ->
                    el.copy(
                        shapeId         = shapeIdMap[el.shapeId] ?: el.shapeId,
                        matrixIndex     = matrixIdMap[el.matrixIndex] ?: el.matrixIndex,
                        colorSpaceIndex = csIdMap[el.colorSpaceIndex] ?: el.colorSpaceIndex
                    )
                }.toMutableList()
                frame.copy(elements = newElements)
            }.toMutableList()
            newMovieclips.add(Movieclip(newMcId, srcMc.fps, newFrames))
        }

        // Add exports
        sourceExports.forEach { exp ->
            newExports.add(exp.copy(
                id          = exp.id + movieclipIdOffset,
                movieclipId = mcIdMap[exp.movieclipId] ?: exp.movieclipId
            ))
        }

        return base.copy(
            exports     = newExports,
            movieclips  = newMovieclips,
            shapes      = newShapes,
            textures    = newTextures,
            matrices    = newMatrices,
            colorSpaces = newColorSpaces
        )
    }

    private fun collectMovieclipIds(mcId: Int, source: ScFile, out: MutableSet<Int>) {
        if (mcId in out) return
        out.add(mcId)
        source.movieclips.find { it.id == mcId }?.frames?.forEach { frame ->
            frame.elements.forEach { el ->
                // Nested movieclips referenced as shapes with the same id range
                if (source.movieclips.any { it.id == el.shapeId }) {
                    collectMovieclipIds(el.shapeId, source, out)
                }
            }
        }
    }
}
