package com.sceditor.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ── Palette ───────────────────────────────────────────────────────────────
val DarkBackground  = Color(0xFF0E0E14)
val DarkSurface     = Color(0xFF1A1A24)
val DarkCard        = Color(0xFF22222E)
val AccentYellow    = Color(0xFFFFD54F)
val AccentBlue      = Color(0xFF64B5F6)
val AccentRed       = Color(0xFFEF5350)
val OnDark          = Color(0xFFE8E8F0)
val OnDarkSecondary = Color(0xFF9898B0)

private val DarkColorScheme = darkColorScheme(
    primary         = AccentYellow,
    onPrimary       = Color(0xFF1A1600),
    secondary       = AccentBlue,
    onSecondary     = Color(0xFF001B30),
    background      = DarkBackground,
    onBackground    = OnDark,
    surface         = DarkSurface,
    onSurface       = OnDark,
    surfaceVariant  = DarkCard,
    onSurfaceVariant = OnDarkSecondary,
    error           = AccentRed,
)

// ── Typography ────────────────────────────────────────────────────────────
val SCTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp,
        letterSpacing = 1.sp
    )
)

// ── Theme ─────────────────────────────────────────────────────────────────
@Composable
fun SCEditorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = SCTypography,
        content     = content
    )
}
