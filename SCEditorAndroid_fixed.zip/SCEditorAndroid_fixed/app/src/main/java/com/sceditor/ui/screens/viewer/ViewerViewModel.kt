package com.sceditor.ui.screens.viewer

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sceditor.data.model.ScFile
import com.sceditor.data.repository.ScRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class ViewerUiState {
    object Idle    : ViewerUiState()
    object Loading : ViewerUiState()
    data class Success(val scFile: ScFile, val saveMessage: String? = null) : ViewerUiState()
    data class Error(val message: String) : ViewerUiState()
}

@HiltViewModel
class ViewerViewModel @Inject constructor(
    private val repo: ScRepository
) : ViewModel() {

    private val _state = MutableStateFlow<ViewerUiState>(ViewerUiState.Idle)
    val state = _state.asStateFlow()

    fun load(uriString: String) {
        // Don't reload if already loaded for the same URI
        val current = _state.value
        if (current is ViewerUiState.Success && current.scFile.path == uriString) return

        viewModelScope.launch {
            _state.value = ViewerUiState.Loading
            repo.openFile(Uri.parse(uriString))
                .onSuccess { _state.value = ViewerUiState.Success(it) }
                .onFailure { _state.value = ViewerUiState.Error(it.message ?: "Unknown error") }
        }
    }

    fun saveAs(uriString: String) {
        val scFile = (state.value as? ViewerUiState.Success)?.scFile ?: return
        viewModelScope.launch {
            repo.saveFile(scFile, Uri.parse(uriString))
                .onSuccess {
                    _state.value = ViewerUiState.Success(scFile, saveMessage = "File saved successfully")
                }
                .onFailure {
                    _state.value = ViewerUiState.Error(it.message ?: "Save failed")
                }
        }
    }

    fun clearSaveMessage() {
        val s = _state.value as? ViewerUiState.Success ?: return
        _state.value = s.copy(saveMessage = null)
    }

    /**
     * Combine a second SC file into the currently loaded one.
     * [sourceUri] is the URI of the source file; [exportIds] are the exports to import.
     */
    fun combineWith(sourceUri: String, exportIds: List<Int>) {
        val base = (state.value as? ViewerUiState.Success)?.scFile ?: return
        viewModelScope.launch {
            repo.openFile(Uri.parse(sourceUri))
                .onSuccess { source ->
                    repo.combineFiles(base, source, exportIds)
                        .onSuccess { combined ->
                            _state.value = ViewerUiState.Success(
                                combined,
                                saveMessage = "Combined ${exportIds.size} export(s) from source file"
                            )
                        }
                        .onFailure { _state.value = ViewerUiState.Error(it.message ?: "Combine failed") }
                }
                .onFailure { _state.value = ViewerUiState.Error(it.message ?: "Cannot open source file") }
        }
    }
}
