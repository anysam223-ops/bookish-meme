package com.sceditor

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SCEditorApp : Application()
