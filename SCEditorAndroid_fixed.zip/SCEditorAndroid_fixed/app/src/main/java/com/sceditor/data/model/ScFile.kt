package com.sceditor.data.model

/**
 * Represents a loaded SC file and all its parsed contents.
 */
data class ScFile(
    val path: String,
    val version: Int,           // 3 or 4
    val compression: Compression,
    val exports: List<Export>,
    val movieclips: List<Movieclip>,
    val shapes: List<Shape>,
    val textures: List<ScTexture>,
    val matrices: List<Matrix>,
    val colorSpaces: List<ColorSpace>,
    val textFields: List<TextField>
)

enum class Compression { LZHAM, LZMA, ZSTD, NONE }

/** A named export pointing to a Movieclip */
data class Export(
    val id: Int,
    val name: String,
    val movieclipId: Int
)

/** Movieclip: a sequence of frames referencing shapes */
data class Movieclip(
    val id: Int,
    val fps: Int,
    val frames: MutableList<MovieclipFrame> = mutableListOf()
)

/** One frame inside a Movieclip */
data class MovieclipFrame(
    val name: String,
    val elements: MutableList<FrameElement> = mutableListOf()
)

/** Element inside a frame: shape + transform */
data class FrameElement(
    val shapeId: Int,
    val matrixIndex: Int,
    val colorSpaceIndex: Int
)

/** A Shape is a collection of ShapeChunks (drawable primitives) */
data class Shape(
    val id: Int,
    val chunks: MutableList<ShapeChunk> = mutableListOf()
)

/** A renderable chunk: UV-mapped quad on a texture */
data class ShapeChunk(
    val id: Int,
    val textureIndex: Int,
    val vertices: List<Vertex>,     // screen-space
    val uvCoords: List<UvCoord>     // texture-space
)

data class Vertex(val x: Float, val y: Float)
data class UvCoord(val u: Float, val v: Float)

/** Texture sheet (an atlas PNG inside the SC) */
data class ScTexture(
    val index: Int,
    val width: Int,
    val height: Int,
    val pixelFormat: PixelFormat,
    val data: ByteArray
) {
    override fun equals(other: Any?) = other is ScTexture && index == other.index
    override fun hashCode() = index
}

enum class PixelFormat { RGBA8888, RGB565, RGBA4444, LA88, L8 }

/** Affine transformation matrix */
data class Matrix(
    val id: Int,
    val a: Float, val b: Float,
    val c: Float, val d: Float,
    val tx: Float, val ty: Float
)

/** Color transform */
data class ColorSpace(
    val id: Int,
    val rMul: Int, val gMul: Int, val bMul: Int, val aMul: Int,
    val rAdd: Int, val gAdd: Int, val bAdd: Int, val aAdd: Int
)

/** Text field definition */
data class TextField(
    val id: Int,
    val text: String,
    val fontName: String,
    val fontSize: Int,
    val color: Int,
    val bold: Boolean,
    val italic: Boolean
)
