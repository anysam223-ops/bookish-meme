package com.sceditor.data.repository

import com.sceditor.data.model.*
import com.sceditor.utils.compress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Serializes a [ScFile] back to the SC binary format.
 * Supports Version 3 output. V4 metadata block generation is not yet implemented.
 */
@Singleton
class ScFileWriter @Inject constructor() {

    companion object {
        private const val MAGIC_SC: Short  = 0x5343
        private const val VERSION_OUT      = 3

        private const val TAG_EOF             = 0
        private const val TAG_TEXTURE         = 1
        private const val TAG_SHAPE           = 2
        private const val TAG_SHAPE_CHUNK     = 6
        private const val TAG_EXPORT          = 7
        private const val TAG_MATRIX          = 8
        private const val TAG_COLOR_SPACE     = 9
        private const val TAG_MOVIECLIP       = 3
        private const val TAG_MOVIECLIP_FRAME = 11
        private const val TAG_TEXTFIELD       = 15
    }

    suspend fun write(scFile: ScFile, out: OutputStream) = withContext(Dispatchers.IO) {
        val payload    = buildPayload(scFile)
        val compressed = payload.compress(scFile.compression)

        val header = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(MAGIC_SC)
            putShort(VERSION_OUT.toShort())
            putInt(compressionId(scFile.compression))
        }.array()

        out.write(header)
        out.write(compressed)
        out.flush()
    }

    private fun buildPayload(scFile: ScFile): ByteArray {
        val baos = ByteArrayOutputStream()

        // Textures first
        scFile.textures.forEach { baos.writeTag(TAG_TEXTURE, writeTexture(it)) }

        // Shapes + their chunks
        scFile.shapes.forEach { shape ->
            baos.writeTag(TAG_SHAPE, writeShape(shape))
            shape.chunks.forEach { chunk ->
                baos.writeTag(TAG_SHAPE_CHUNK, writeChunk(chunk))
            }
        }

        // Exports (must come after shapes/movieclips so IDs are valid)
        if (scFile.exports.isNotEmpty()) {
            baos.writeTag(TAG_EXPORT, writeExports(scFile.exports))
        }

        // Matrices
        scFile.matrices.forEach { baos.writeTag(TAG_MATRIX, writeMatrix(it)) }

        // Color spaces
        scFile.colorSpaces.forEach { baos.writeTag(TAG_COLOR_SPACE, writeColorSpace(it)) }

        // Movieclips + frames
        scFile.movieclips.forEach { mc ->
            baos.writeTag(TAG_MOVIECLIP, writeMovieclip(mc))
            mc.frames.forEach { frame ->
                baos.writeTag(TAG_MOVIECLIP_FRAME, writeFrame(frame))
            }
        }

        // Text fields
        scFile.textFields.forEach { baos.writeTag(TAG_TEXTFIELD, writeTextField(it)) }

        // EOF tag
        baos.write(TAG_EOF)

        return baos.toByteArray()
    }

    // ---- Serializers ----

    private fun writeTexture(t: ScTexture): ByteArray {
        val typeId = when (t.pixelFormat) {
            PixelFormat.RGBA8888 -> 0
            PixelFormat.RGBA4444 -> 2
            PixelFormat.RGB565   -> 4
            PixelFormat.LA88     -> 6
            PixelFormat.L8       -> 10
        }
        return ByteBuffer.allocate(5 + t.data.size).order(ByteOrder.LITTLE_ENDIAN).apply {
            put(typeId.toByte())
            putShort(t.width.toShort())
            putShort(t.height.toShort())
            put(t.data)
        }.array()
    }

    private fun writeShape(shape: Shape): ByteArray =
        ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(shape.id.toShort())
            putShort(shape.chunks.size.toShort()) // declare chunk count
        }.array()

    private fun writeChunk(chunk: ShapeChunk): ByteArray {
        val count = chunk.vertices.size
        // 2 (id) + 1 (texIdx) + 1 (count) + count*8 (vertices i32×2) + count*4 (uvs u16×2)
        val buf = ByteBuffer.allocate(4 + count * 8 + count * 4).order(ByteOrder.LITTLE_ENDIAN)
        buf.putShort(chunk.id.toShort())
        buf.put(chunk.textureIndex.toByte())
        buf.put(count.toByte())
        chunk.vertices.forEach { v ->
            buf.putInt((v.x * 20).toInt())
            buf.putInt((v.y * 20).toInt())
        }
        chunk.uvCoords.forEach { uv ->
            buf.putShort((uv.u * 65535f).toInt().toShort())
            buf.putShort((uv.v * 65535f).toInt().toShort())
        }
        return buf.array()
    }

    private fun writeMovieclip(mc: Movieclip): ByteArray =
        ByteBuffer.allocate(3).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(mc.id.toShort())
            put(mc.fps.toByte())
        }.array()

    private fun writeFrame(frame: MovieclipFrame): ByteArray {
        val nameBytes = frame.name.toByteArray(Charsets.UTF_8)
        val elemCount = frame.elements.size
        return ByteBuffer.allocate(2 + nameBytes.size + 2 + elemCount * 6)
            .order(ByteOrder.LITTLE_ENDIAN).apply {
                putShort(nameBytes.size.toShort())
                put(nameBytes)
                putShort(elemCount.toShort())
                frame.elements.forEach { el ->
                    putShort(el.shapeId.toShort())
                    putShort(el.matrixIndex.toShort())
                    putShort(el.colorSpaceIndex.toShort())
                }
            }.array()
    }

    private fun writeMatrix(m: Matrix): ByteArray =
        ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN).apply {
            putInt((m.a * 1024).toInt()); putInt((m.b * 1024).toInt())
            putInt((m.c * 1024).toInt()); putInt((m.d * 1024).toInt())
            putInt((m.tx * 20).toInt());  putInt((m.ty * 20).toInt())
        }.array()

    private fun writeColorSpace(cs: ColorSpace): ByteArray = byteArrayOf(
        cs.rMul.toByte(), cs.gMul.toByte(), cs.bMul.toByte(), cs.aMul.toByte(),
        cs.rAdd.toByte(), cs.gAdd.toByte(), cs.bAdd.toByte(), cs.aAdd.toByte()
    )

    /**
     * Export block layout (mirrors parseExports):
     *   2 bytes: count
     *   count × 2 bytes: movieclip IDs
     *   count × (2-byte name-len + N bytes name)
     */
    private fun writeExports(exports: List<Export>): ByteArray {
        val baos = ByteArrayOutputStream()
        val countBuf = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN)
            .putShort(exports.size.toShort()).array()
        baos.write(countBuf)
        // Write all movieclip IDs first
        exports.forEach { exp ->
            baos.write(ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN)
                .putShort(exp.movieclipId.toShort()).array())
        }
        // Then all names
        exports.forEach { exp ->
            val nameBytes = exp.name.toByteArray(Charsets.UTF_8)
            baos.write(ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN)
                .putShort(nameBytes.size.toShort()).array())
            baos.write(nameBytes)
        }
        return baos.toByteArray()
    }

    private fun writeTextField(tf: TextField): ByteArray {
        val baos = ByteArrayOutputStream()
        fun writeStr(s: String) {
            val b = s.toByteArray(Charsets.UTF_8)
            baos.write(ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN)
                .putShort(b.size.toShort()).array())
            baos.write(b)
        }
        baos.write(ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN)
            .putShort(tf.id.toShort()).array())
        writeStr(tf.text)
        writeStr(tf.fontName)
        var flags = 0
        if (tf.bold)   flags = flags or 0x01
        if (tf.italic) flags = flags or 0x02
        baos.write(ByteBuffer.allocate(7).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(tf.fontSize.toShort())
            putInt(tf.color)
            put(flags.toByte())
        }.array())
        return baos.toByteArray()
    }

    private fun compressionId(c: Compression) = when (c) {
        Compression.LZHAM -> 0x04
        Compression.LZMA  -> 0x01
        Compression.ZSTD  -> 0x28
        Compression.NONE  -> 0x00
    }

    private fun ByteArrayOutputStream.writeTag(tag: Int, data: ByteArray) {
        write(tag)
        write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(data.size).array())
        write(data)
    }
}
