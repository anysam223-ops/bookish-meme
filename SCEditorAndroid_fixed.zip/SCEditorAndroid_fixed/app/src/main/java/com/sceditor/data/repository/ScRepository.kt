package com.sceditor.data.repository

import android.content.Context
import android.net.Uri
import com.sceditor.data.model.ScFile
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val parser: ScFileParser,
    private val writer: ScFileWriter
) {

    /** Open and parse an SC file from a [Uri] (Storage Access Framework). */
    suspend fun openFile(uri: Uri): Result<ScFile> = withContext(Dispatchers.IO) {
        runCatching {
            val stream = context.contentResolver.openInputStream(uri)
                ?: error("Cannot open file: $uri")
            val scFile = parser.parse(stream).getOrThrow()
            // Attach the uri path for display
            scFile.copy(path = uri.toString())
        }
    }

    /** Save an SC file to a [Uri]. */
    suspend fun saveFile(scFile: ScFile, uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val stream = context.contentResolver.openOutputStream(uri)
                ?: error("Cannot write file: $uri")
            writer.write(scFile, stream)
        }
    }

    /** Export a texture to a PNG file in the app cache directory. */
    suspend fun exportTexturePng(scFile: ScFile, textureIndex: Int): Result<File> =
        withContext(Dispatchers.IO) {
            runCatching {
                val texture = scFile.textures[textureIndex]
                val cacheFile = File(context.cacheDir, "texture_$textureIndex.png")
                // Convert raw pixel data → Bitmap → PNG
                val bitmap = texture.toBitmap()
                cacheFile.outputStream().use { out ->
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
                }
                cacheFile
            }
        }

    /** Combine this file with another SC file by importing selected exports. */
    suspend fun combineFiles(
        base: ScFile,
        source: ScFile,
        exportIds: List<Int>
    ): Result<ScFile> = withContext(Dispatchers.IO) {
        runCatching {
            ScFileCombiner.combine(base, source, exportIds)
        }
    }
}
