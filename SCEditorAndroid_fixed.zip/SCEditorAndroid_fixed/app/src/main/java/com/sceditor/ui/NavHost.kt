package com.sceditor.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sceditor.ui.screens.editor.EditorScreen
import com.sceditor.ui.screens.home.HomeScreen
import com.sceditor.ui.screens.viewer.ViewerScreen

sealed class Screen(val route: String) {
    object Home    : Screen("home")
    object Viewer  : Screen("viewer/{fileUri}") {
        fun go(uri: String) = "viewer/${uri.encode()}"
    }
    object Editor  : Screen("editor/{fileUri}/{exportId}") {
        fun go(uri: String, exportId: Int) = "editor/${uri.encode()}/$exportId"
    }
}

private fun String.encode() = java.net.URLEncoder.encode(this, "UTF-8")

@Composable
fun SCEditorNavHost() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Screen.Home.route) {

        composable(Screen.Home.route) {
            HomeScreen(
                onFileOpened = { uri -> nav.navigate(Screen.Viewer.go(uri)) }
            )
        }

        composable(
            route = Screen.Viewer.route,
            arguments = listOf(navArgument("fileUri") { type = NavType.StringType })
        ) { back ->
            val rawUri = back.arguments?.getString("fileUri") ?: return@composable
            val uri = java.net.URLDecoder.decode(rawUri, "UTF-8")
            ViewerScreen(
                fileUri    = uri,
                onNavigateBack = { nav.popBackStack() },
                onEditExport   = { exportId -> nav.navigate(Screen.Editor.go(uri, exportId)) }
            )
        }

        composable(
            route = Screen.Editor.route,
            arguments = listOf(
                navArgument("fileUri")  { type = NavType.StringType },
                navArgument("exportId") { type = NavType.IntType }
            )
        ) { back ->
            val rawUri   = back.arguments?.getString("fileUri") ?: return@composable
            val uri      = java.net.URLDecoder.decode(rawUri, "UTF-8")
            val exportId = back.arguments?.getInt("exportId") ?: 0
            EditorScreen(
                fileUri        = uri,
                exportId       = exportId,
                onNavigateBack = { nav.popBackStack() }
            )
        }
    }
}
