package com.sceditor.utils

import com.sceditor.data.model.Compression
import org.apache.commons.compress.compressors.lzma.LZMACompressorInputStream
import org.apache.commons.compress.compressors.lzma.LZMACompressorOutputStream
import org.apache.commons.compress.compressors.zstandard.ZstdCompressorInputStream
import org.apache.commons.compress.compressors.zstandard.ZstdCompressorOutputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/**
 * Decompress bytes using the given [Compression] algorithm.
 * LZHAM is currently stubbed — the native library must be integrated separately.
 */
fun ByteArray.decompress(compression: Compression): ByteArray = when (compression) {
    Compression.LZMA -> decompressLzma(this)
    Compression.ZSTD -> decompressZstd(this)
    Compression.LZHAM -> decompressLzham(this) // requires native lib
    Compression.NONE -> this
}

fun ByteArray.compress(compression: Compression): ByteArray = when (compression) {
    Compression.LZMA -> compressLzma(this)
    Compression.ZSTD -> compressZstd(this)
    Compression.LZHAM -> compressLzham(this)
    Compression.NONE -> this
}

// ---- LZMA ----
private fun decompressLzma(data: ByteArray): ByteArray {
    val baos = ByteArrayOutputStream()
    LZMACompressorInputStream(ByteArrayInputStream(data)).use { it.copyTo(baos) }
    return baos.toByteArray()
}
private fun compressLzma(data: ByteArray): ByteArray {
    val baos = ByteArrayOutputStream()
    LZMACompressorOutputStream(baos).use { it.write(data) }
    return baos.toByteArray()
}

// ---- ZSTD ----
private fun decompressZstd(data: ByteArray): ByteArray {
    val baos = ByteArrayOutputStream()
    ZstdCompressorInputStream(ByteArrayInputStream(data)).use { it.copyTo(baos) }
    return baos.toByteArray()
}
private fun compressZstd(data: ByteArray): ByteArray {
    val baos = ByteArrayOutputStream()
    ZstdCompressorOutputStream(baos).use { it.write(data) }
    return baos.toByteArray()
}

// ---- LZHAM (Native stub) ----
// To enable: integrate the lzham_android native library and implement JNI bridge.
private fun decompressLzham(data: ByteArray): ByteArray {
    throw UnsupportedOperationException(
        "LZHAM decompression requires a native JNI library. " +
        "See README for integration instructions."
    )
}
private fun compressLzham(data: ByteArray): ByteArray {
    throw UnsupportedOperationException(
        "LZHAM compression requires a native JNI library."
    )
}
