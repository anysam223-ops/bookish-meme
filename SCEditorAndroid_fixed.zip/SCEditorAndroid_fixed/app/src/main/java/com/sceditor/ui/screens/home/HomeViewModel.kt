package com.sceditor.ui.screens.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val prefs = context.getSharedPreferences("sc_editor_prefs", Context.MODE_PRIVATE)
    private val KEY   = "recent_files_ordered"

    private val _recentFiles = MutableStateFlow<List<String>>(emptyList())
    val recentFiles = _recentFiles.asStateFlow()

    init { loadRecent() }

    fun addRecent(uri: String) {
        val updated = (_recentFiles.value.filter { it != uri }).toMutableList()
            .apply { add(0, uri) }
            .take(10)
        _recentFiles.value = updated
        saveRecent(updated)
    }

    fun removeRecent(uri: String) {
        val updated = _recentFiles.value.filter { it != uri }
        _recentFiles.value = updated
        saveRecent(updated)
    }

    fun clearRecent() {
        _recentFiles.value = emptyList()
        prefs.edit().remove(KEY).apply()
    }

    private fun loadRecent() {
        val raw = prefs.getString(KEY, "") ?: ""
        _recentFiles.value = if (raw.isBlank()) emptyList()
        else raw.split("\u0000").filter { it.isNotBlank() }
    }

    private fun saveRecent(list: List<String>) {
        prefs.edit().putString(KEY, list.joinToString("\u0000")).apply()
    }
}
