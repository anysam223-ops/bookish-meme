package com.sceditor.ui.screens.home

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sceditor.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onFileOpened: (String) -> Unit,
    vm: HomeViewModel = hiltViewModel()
) {
    val recentFiles by vm.recentFiles.collectAsState()

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            vm.addRecent(it.toString())
            onFileOpened(it.toString())
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "SC Editor",
                        fontFamily = FontFamily.Monospace,
                        color = AccentYellow
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface
                ),
                actions = {
                    IconButton(onClick = { vm.clearRecent() }) {
                        Icon(Icons.Default.Delete, contentDescription = "Clear recent",
                            tint = OnDarkSecondary)
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { filePicker.launch(arrayOf("application/octet-stream", "*/*")) },
                icon = { Icon(Icons.Default.FolderOpen, contentDescription = null) },
                text = { Text("Open SC File") },
                containerColor = AccentYellow,
                contentColor   = DarkBackground
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(16.dp))

            // Header
            Text(
                "Supercell SC Editor",
                style = MaterialTheme.typography.headlineMedium,
                color = OnDark
            )
            Text(
                "Clash of Clans · Clash Royale · Brawl Stars · Boom Beach",
                style = MaterialTheme.typography.bodySmall,
                color = OnDarkSecondary
            )

            Spacer(Modifier.height(24.dp))

            // Feature chips
            FeatureChips()

            Spacer(Modifier.height(24.dp))

            // Recent files
            if (recentFiles.isEmpty()) {
                EmptyState()
            } else {
                Text(
                    "RECENT FILES",
                    style = MaterialTheme.typography.labelSmall,
                    color = OnDarkSecondary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(recentFiles) { path ->
                        RecentFileCard(
                            path      = path,
                            onClick   = { onFileOpened(path) },
                            onRemove  = { vm.removeRecent(path) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureChips() {
    val features = listOf(
        "Decompress LZMA/ZSTD" to Icons.Default.Lock,
        "View Animations"       to Icons.Default.PlayCircle,
        "Edit Textures"         to Icons.Default.Image,
        "Combine SC Files"      to Icons.Default.MergeType,
        "Live Edit"             to Icons.Default.Edit,
        "Export PNG"            to Icons.Default.Download
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        features.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (label, icon) ->
                    AssistChip(
                        onClick = {},
                        label   = { Text(label, style = MaterialTheme.typography.bodySmall) },
                        leadingIcon = {
                            Icon(icon, contentDescription = null,
                                modifier = Modifier.size(14.dp))
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor    = DarkCard,
                            labelColor        = OnDarkSecondary,
                            leadingIconContentColor = AccentBlue
                        ),
                        border = AssistChipDefaults.assistChipBorder(
                            enabled = true,
                            borderColor = DarkCard
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun RecentFileCard(path: String, onClick: () -> Unit, onRemove: () -> Unit) {
    val fileName = path.substringAfterLast("/").substringAfterLast("%2F")

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkCard)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Default.InsertDriveFile,
            contentDescription = null,
            tint = AccentYellow,
            modifier = Modifier.size(32.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                fileName,
                style = MaterialTheme.typography.titleMedium,
                color = OnDark,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                path,
                style = MaterialTheme.typography.bodySmall,
                color = OnDarkSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onRemove) {
            Icon(Icons.Default.Close, contentDescription = "Remove",
                tint = OnDarkSecondary, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun EmptyState() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                Icons.Default.FolderOpen,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = OnDarkSecondary
            )
            Spacer(Modifier.height(16.dp))
            Text("No recent files", color = OnDarkSecondary)
            Text("Tap the button below to open an SC file",
                style = MaterialTheme.typography.bodySmall,
                color = OnDarkSecondary)
        }
    }
}
