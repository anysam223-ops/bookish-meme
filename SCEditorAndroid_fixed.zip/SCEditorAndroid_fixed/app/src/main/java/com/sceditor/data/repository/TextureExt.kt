package com.sceditor.data.repository

import android.graphics.Bitmap
import com.sceditor.data.model.PixelFormat
import com.sceditor.data.model.ScTexture

/**
 * Converts a [ScTexture]'s raw pixel buffer into an Android [Bitmap].
 */
fun ScTexture.toBitmap(): Bitmap {
    val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val pixels = IntArray(width * height)
    var i = 0
    var p = 0
    while (p < pixels.size) {
        val argb = when (pixelFormat) {
            PixelFormat.RGBA8888 -> {
                val r = data[i++].toInt() and 0xFF
                val g = data[i++].toInt() and 0xFF
                val b = data[i++].toInt() and 0xFF
                val a = data[i++].toInt() and 0xFF
                (a shl 24) or (r shl 16) or (g shl 8) or b
            }
            PixelFormat.RGBA4444 -> {
                val raw = ((data[i++].toInt() and 0xFF) or ((data[i++].toInt() and 0xFF) shl 8))
                val r = ((raw shr 12) and 0xF) * 17
                val g = ((raw shr 8) and 0xF) * 17
                val b = ((raw shr 4) and 0xF) * 17
                val a = (raw and 0xF) * 17
                (a shl 24) or (r shl 16) or (g shl 8) or b
            }
            PixelFormat.RGB565 -> {
                val raw = ((data[i++].toInt() and 0xFF) or ((data[i++].toInt() and 0xFF) shl 8))
                val r = ((raw shr 11) and 0x1F) * 255 / 31
                val g = ((raw shr 5) and 0x3F) * 255 / 63
                val b = (raw and 0x1F) * 255 / 31
                (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            PixelFormat.LA88 -> {
                val l = data[i++].toInt() and 0xFF
                val a = data[i++].toInt() and 0xFF
                (a shl 24) or (l shl 16) or (l shl 8) or l
            }
            PixelFormat.L8 -> {
                val l = data[i++].toInt() and 0xFF
                (0xFF shl 24) or (l shl 16) or (l shl 8) or l
            }
        }
        pixels[p++] = argb
    }
    bmp.setPixels(pixels, 0, width, 0, 0, width, height)
    return bmp
}
