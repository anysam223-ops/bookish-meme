# SC Editor – Android

Port of the [Supercell SC Editor](https://github.com/abdudsoul/SCEditor) to Android using **Kotlin + Jetpack Compose**.

Supports Clash of Clans · Clash Royale · Brawl Stars · Boom Beach SC files.

## Architecture

```
app/
└── java/com/sceditor/
    ├── data/
    │   ├── model/         ← ScFile, Export, Movieclip, Shape, Texture…
    │   └── repository/    ← ScFileParser, ScFileWriter, ScFileCombiner, ScRepository
    ├── ui/
    │   ├── theme/         ← Dark theme (0xFF0E0E14), AccentYellow, AccentBlue
    │   ├── screens/
    │   │   ├── home/      ← File picker + ordered recent files list
    │   │   ├── viewer/    ← File overview: Exports / Shapes / Textures / Matrices / Info tabs
    │   │   └── editor/    ← Live export editing + D-pad / manual position controls
    │   └── NavHost.kt
    ├── utils/
    │   └── Compression.kt ← LZMA, ZSTD (Apache Commons Compress); LZHAM native stub
    ├── MainActivity.kt
    └── SCEditorApp.kt
```

## Features implemented

- Parse SC v3 / v4 binary format (header + tag-block stream)
- Decompress **LZMA** and **ZSTD** payloads via Apache Commons Compress
- **LZHAM** stub — requires a native JNI `.so` library (see *Known limitations*)
- View Exports, Movieclips, Shapes, Textures, Matrices in scrollable tabs
- **Live edit**: select a frame element → move X/Y with D-pad or manual Δ input
- Add / remove Movieclip frames
- Clone exports (creates a new Export + Movieclip with deep-copied frames)
- **Combine two SC files** — merge selected exports and their full dependency tree
  (shapes, matrices, color-spaces, textures) with automatic ID remapping
- Convert raw texture pixel buffers to Android `Bitmap` / export as PNG
- Save back to SC binary (v3 output) via Storage Access Framework
- Open SC files via SAF file picker or direct `VIEW` intent from a file manager
- Ordered recent-files list (up to 10 entries, persisted across sessions)

## Requirements

- Android 8.0+ (API 26)
- Kotlin 2.0 · Jetpack Compose · Hilt · Room · Coroutines

## Building

```bash
./gradlew assembleDebug
```

Run with Android Studio in **Debug** mode to capture any parsing exceptions in Logcat.

## Known limitations  *(mirrors the desktop version)*

| Issue | Status |
|-------|--------|
| V4 saving | Skipped — METADATA block generation unknown |
| LZHAM | Requires integrating a native `.so` (JNI bridge stub provided) |
| Animation preview | Not yet implemented — canvas renderer planned |
| TexturePacker integration | Not applicable on Android; pure-Kotlin bin-packing planned |
| Cloning reflects changes on original | Until file is saved & reopened (soft-copy references) |

## Credits

[Jean-Baptiste Martin (Ultrapowa)](https://github.com/jeanbmar) – original USC SC Editor  
[Mike Chiappe (Mimi)](https://github.com/Mimi8298) – object variable research  
Original desktop SC Editor by [abdudsoul](https://github.com/abdudsoul/SCEditor)
