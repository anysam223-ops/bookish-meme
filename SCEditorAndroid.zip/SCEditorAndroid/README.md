# SC Editor – Android

Port of the Supercell SC Editor to Android using **Kotlin + Jetpack Compose**.

## Architecture

```
app/
└── java/com/sceditor/
    ├── data/
    │   ├── model/         ← ScFile, Export, Movieclip, Shape, Texture…
    │   └── repository/    ← ScFileParser, ScFileWriter, ScFileCombiner, ScRepository
    ├── ui/
    │   ├── theme/         ← Dark theme, colors, typography
    │   ├── screens/
    │   │   ├── home/      ← File picker + recent files
    │   │   ├── viewer/    ← File overview (exports, shapes, textures tabs)
    │   │   └── editor/    ← Live export editing + position controls
    │   └── NavHost.kt
    ├── utils/
    │   └── Compression.kt ← LZMA, ZSTD, LZHAM (native stub)
    ├── MainActivity.kt
    └── SCEditorApp.kt
```

## Features implemented

- Parse SC v3 / v4 binary format (header + tag blocks)
- Decompress LZMA and ZSTD payloads
- LZHAM stub (requires native JNI library integration)
- View Exports, Movieclips, Shapes, Textures, Matrices
- Live edit: select frame element → move X/Y via D-pad or manual input
- Add / remove Movieclip frames
- Clone exports
- Combine two SC files (merge selected exports + full dependency tree)
- Convert textures to Android Bitmap / export PNG
- Save back to uncompressed SC file (v3 output)
- Open SC files via SAF (Storage Access Framework) or direct intent

## Requirements

- Android 8.0+ (API 26)
- Kotlin 2.0, Jetpack Compose, Hilt, Room

## Known limitations (mirrors desktop version)

- V4 saving is not yet supported (METADATA block generation unknown)
- LZHAM requires integrating a native `.so` library
- Animation preview renderer not yet implemented (canvas-based renderer planned)
- TexturePacker integration not applicable on Android – texture atlas generation
  is planned using a pure-Kotlin bin-packing implementation

## Credits

Jean-Baptiste Martin (Ultrapowa) – original USC SC Editor  
Mike Chiappe (Mimi) – object variable research  
Original desktop SC Editor by abdudsoul
