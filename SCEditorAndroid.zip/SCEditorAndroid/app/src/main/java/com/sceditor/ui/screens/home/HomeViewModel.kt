package com.sceditor.ui.screens.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val prefs = context.getSharedPreferences("sc_editor_prefs", Context.MODE_PRIVATE)
    private val KEY   = "recent_files"

    private val _recentFiles = MutableStateFlow<List<String>>(emptyList())
    val recentFiles = _recentFiles.asStateFlow()

    init { loadRecent() }

    fun addRecent(uri: String) {
        val updated = (_recentFiles.value - uri).toMutableList().apply { add(0, uri) }.take(10)
        _recentFiles.value = updated
        saveRecent(updated)
    }

    fun removeRecent(uri: String) {
        val updated = _recentFiles.value - uri
        _recentFiles.value = updated
        saveRecent(updated)
    }

    fun clearRecent() {
        _recentFiles.value = emptyList()
        prefs.edit().remove(KEY).apply()
    }

    private fun loadRecent() {
        _recentFiles.value = prefs.getStringSet(KEY, emptySet())?.toList() ?: emptyList()
    }

    private fun saveRecent(list: List<String>) {
        prefs.edit().putStringSet(KEY, list.toSet()).apply()
    }
}
