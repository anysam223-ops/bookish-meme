package com.sceditor.data.repository

import android.content.Context
import com.sceditor.data.model.*
import com.sceditor.utils.decompress
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Parses raw .sc binary files into [ScFile] data model.
 *
 * SC Format overview:
 *  - 2 bytes: magic ("SC")
 *  - 2 bytes: version (3 or 4)
 *  - 4 bytes: compression type
 *  - [compressed payload containing tags]
 *
 * Each tag block:
 *  - 1 byte:  tag id
 *  - 4 bytes: block length
 *  - N bytes: block data
 */
@Singleton
class ScFileParser @Inject constructor(
    @ApplicationContext private val context: Context
) {

    companion object {
        private const val MAGIC_SC = 0x5343  // "SC"

        // Tag IDs
        private const val TAG_EOF           = 0
        private const val TAG_TEXTURE       = 1
        private const val TAG_SHAPE         = 2
        private const val TAG_MOVIECLIP     = 3
        private const val TAG_SHAPE_CHUNK   = 6
        private const val TAG_MATRIX        = 8
        private const val TAG_COLOR_SPACE   = 9
        private const val TAG_EXPORT        = 7
        private const val TAG_MOVIECLIP_FRAME = 11
        private const val TAG_TEXTFIELD     = 15
        private const val TAG_MOVIECLIP_V2 = 12
        private const val TAG_SHAPE_V2     = 18
    }

    /** Parse a .sc file from a raw [InputStream]. */
    suspend fun parse(stream: InputStream): Result<ScFile> = withContext(Dispatchers.IO) {
        runCatching {
            val rawBytes = stream.readBytes()
            val buf = ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN)

            // --- Header ---
            val magic = buf.short.toInt() and 0xFFFF
            require(magic == MAGIC_SC) { "Invalid SC file: wrong magic bytes" }

            val version = (buf.short.toInt() and 0xFFFF)
            require(version in 3..4) { "Unsupported SC version: $version" }

            val compressionId = buf.int
            val compression = when (compressionId) {
                0x04 -> Compression.LZHAM
                0x01 -> Compression.LZMA
                0x28 -> Compression.ZSTD
                else -> Compression.NONE
            }

            // Skip hash bytes (16 bytes MD5 in v4)
            if (version == 4) repeat(16) { buf.get() }

            // --- Decompress payload ---
            val compressedData = ByteArray(buf.remaining()).also { buf.get(it) }
            val decompressed = compressedData.decompress(compression)
            val payload = ByteBuffer.wrap(decompressed).order(ByteOrder.LITTLE_ENDIAN)

            // --- Parse tags ---
            val exports     = mutableListOf<Export>()
            val movieclips  = mutableListOf<Movieclip>()
            val shapes      = mutableListOf<Shape>()
            val textures    = mutableListOf<ScTexture>()
            val matrices    = mutableListOf<Matrix>()
            val colorSpaces = mutableListOf<ColorSpace>()
            val textFields  = mutableListOf<TextField>()

            while (payload.hasRemaining()) {
                val tagId = payload.get().toInt() and 0xFF
                if (tagId == TAG_EOF) break
                val blockLen = payload.int

                val block = ByteArray(blockLen).also { payload.get(it) }
                val b = ByteBuffer.wrap(block).order(ByteOrder.LITTLE_ENDIAN)

                when (tagId) {
                    TAG_TEXTURE       -> textures.add(parseTexture(b, textures.size))
                    TAG_SHAPE,
                    TAG_SHAPE_V2      -> shapes.add(parseShape(b))
                    TAG_MOVIECLIP,
                    TAG_MOVIECLIP_V2  -> movieclips.add(parseMovieclip(b))
                    TAG_MOVIECLIP_FRAME -> appendFrame(movieclips, b)
                    TAG_SHAPE_CHUNK   -> appendChunk(shapes, b)
                    TAG_MATRIX        -> matrices.add(parseMatrix(b, matrices.size))
                    TAG_COLOR_SPACE   -> colorSpaces.add(parseColorSpace(b, colorSpaces.size))
                    TAG_EXPORT        -> exports.addAll(parseExports(b))
                    TAG_TEXTFIELD     -> textFields.add(parseTextField(b))
                }
            }

            ScFile(
                path = "",
                version = version,
                compression = compression,
                exports = exports,
                movieclips = movieclips,
                shapes = shapes,
                textures = textures,
                matrices = matrices,
                colorSpaces = colorSpaces,
                textFields = textFields
            )
        }
    }

    // ---- Tag parsers ----

    private fun parseTexture(b: ByteBuffer, index: Int): ScTexture {
        val type = b.get().toInt() and 0xFF
        val width = b.short.toInt() and 0xFFFF
        val height = b.short.toInt() and 0xFFFF
        val format = when (type) {
            0 -> PixelFormat.RGBA8888
            2 -> PixelFormat.RGBA4444
            4 -> PixelFormat.RGB565
            6 -> PixelFormat.LA88
            10 -> PixelFormat.L8
            else -> PixelFormat.RGBA8888
        }
        val pixelBytes = when (format) {
            PixelFormat.RGBA8888 -> 4
            PixelFormat.RGBA4444, PixelFormat.RGB565, PixelFormat.LA88 -> 2
            PixelFormat.L8 -> 1
        }
        val data = ByteArray(width * height * pixelBytes).also { b.get(it) }
        return ScTexture(index, width, height, format, data)
    }

    private fun parseShape(b: ByteBuffer): Shape {
        val id = b.short.toInt() and 0xFFFF
        return Shape(id)
    }

    private fun appendChunk(shapes: MutableList<Shape>, b: ByteBuffer) {
        val chunkId = b.short.toInt() and 0xFFFF
        val texIndex = b.get().toInt() and 0xFF
        val count = b.get().toInt() and 0xFF
        val vertices = (0 until count).map {
            Vertex(b.int / 20f, b.int / 20f)
        }
        val uvCoords = (0 until count).map {
            UvCoord(
                (b.short.toInt() and 0xFFFF) / 65535f,
                (b.short.toInt() and 0xFFFF) / 65535f
            )
        }
        val chunk = ShapeChunk(chunkId, texIndex, vertices, uvCoords)
        shapes.lastOrNull()?.chunks?.add(chunk)
    }

    private fun parseMovieclip(b: ByteBuffer): Movieclip {
        val id = b.short.toInt() and 0xFFFF
        val fps = b.get().toInt() and 0xFF
        return Movieclip(id, fps)
    }

    private fun appendFrame(movieclips: MutableList<Movieclip>, b: ByteBuffer) {
        val nameLen = b.short.toInt() and 0xFFFF
        val nameBytes = ByteArray(nameLen).also { b.get(it) }
        val name = String(nameBytes, Charsets.UTF_8)
        val elementCount = b.short.toInt() and 0xFFFF
        val elements = (0 until elementCount).map {
            FrameElement(
                shapeId        = b.short.toInt() and 0xFFFF,
                matrixIndex    = b.short.toInt() and 0xFFFF,
                colorSpaceIndex = b.short.toInt() and 0xFFFF
            )
        }
        val frame = MovieclipFrame(name, elements.toMutableList())
        movieclips.lastOrNull()?.frames?.add(frame)
    }

    private fun parseMatrix(b: ByteBuffer, id: Int): Matrix {
        return Matrix(
            id = id,
            a = b.int / 1024f, b = b.int / 1024f,
            c = b.int / 1024f, d = b.int / 1024f,
            tx = b.int / 20f, ty = b.int / 20f
        )
    }

    private fun parseColorSpace(b: ByteBuffer, id: Int): ColorSpace {
        return ColorSpace(
            id = id,
            rMul = b.get().toInt() and 0xFF,
            gMul = b.get().toInt() and 0xFF,
            bMul = b.get().toInt() and 0xFF,
            aMul = b.get().toInt() and 0xFF,
            rAdd = b.get().toInt() and 0xFF,
            gAdd = b.get().toInt() and 0xFF,
            bAdd = b.get().toInt() and 0xFF,
            aAdd = b.get().toInt() and 0xFF
        )
    }

    private fun parseExports(b: ByteBuffer): List<Export> {
        val count = b.short.toInt() and 0xFFFF
        val ids = (0 until count).map { b.short.toInt() and 0xFFFF }
        return ids.mapIndexed { i, id ->
            val nameLen = b.short.toInt() and 0xFFFF
            val nameBytes = ByteArray(nameLen).also { b.get(it) }
            Export(id, String(nameBytes, Charsets.UTF_8), movieclipId = id)
        }
    }

    private fun parseTextField(b: ByteBuffer): TextField {
        val id = b.short.toInt() and 0xFFFF
        fun readString(): String {
            val len = b.short.toInt() and 0xFFFF
            return String(ByteArray(len).also { b.get(it) }, Charsets.UTF_8)
        }
        val text = readString()
        val fontName = readString()
        val fontSize = b.short.toInt() and 0xFFFF
        val color = b.int
        val flags = b.get().toInt() and 0xFF
        return TextField(id, text, fontName, fontSize, color,
            bold = flags and 0x01 != 0,
            italic = flags and 0x02 != 0
        )
    }
}
