package com.sceditor.ui.screens.viewer

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sceditor.data.model.ScFile
import com.sceditor.data.repository.ScRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class ViewerUiState {
    object Idle    : ViewerUiState()
    object Loading : ViewerUiState()
    data class Success(val scFile: ScFile) : ViewerUiState()
    data class Error(val message: String)  : ViewerUiState()
}

@HiltViewModel
class ViewerViewModel @Inject constructor(
    private val repo: ScRepository
) : ViewModel() {

    private val _state = MutableStateFlow<ViewerUiState>(ViewerUiState.Idle)
    val state = _state.asStateFlow()

    fun load(uriString: String) {
        viewModelScope.launch {
            _state.value = ViewerUiState.Loading
            repo.openFile(Uri.parse(uriString))
                .onSuccess { _state.value = ViewerUiState.Success(it) }
                .onFailure { _state.value = ViewerUiState.Error(it.message ?: "Unknown error") }
        }
    }

    fun saveAs(uriString: String) {
        val scFile = (state.value as? ViewerUiState.Success)?.scFile ?: return
        viewModelScope.launch {
            repo.saveFile(scFile, Uri.parse(uriString))
        }
    }
}
