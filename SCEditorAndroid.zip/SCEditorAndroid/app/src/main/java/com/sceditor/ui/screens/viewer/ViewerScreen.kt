package com.sceditor.ui.screens.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sceditor.data.model.*
import com.sceditor.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewerScreen(
    fileUri: String,
    onNavigateBack: () -> Unit,
    onEditExport: (Int) -> Unit,
    vm: ViewerViewModel = hiltViewModel()
) {
    LaunchedEffect(fileUri) { vm.load(fileUri) }
    val state by vm.state.collectAsState()
    val fileName = fileUri.substringAfterLast("/").substringAfterLast("%2F")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(fileName, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = OnDark) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, null, tint = OnDark)
                    }
                },
                actions = {
                    IconButton(onClick = { /* save as */ }) {
                        Icon(Icons.Default.Save, null, tint = AccentYellow)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        when (val s = state) {
            is ViewerUiState.Idle    -> {}
            is ViewerUiState.Loading -> LoadingView(Modifier.padding(padding))
            is ViewerUiState.Error   -> ErrorView(s.message, Modifier.padding(padding))
            is ViewerUiState.Success -> ScFileTabs(s.scFile, onEditExport, Modifier.padding(padding))
        }
    }
}

@Composable
private fun ScFileTabs(scFile: ScFile, onEditExport: (Int) -> Unit, modifier: Modifier) {
    val tabs  = listOf("Exports", "Shapes", "Textures", "Matrices", "Info")
    var tabIdx by remember { mutableIntStateOf(0) }

    Column(modifier.fillMaxSize()) {
        // Metadata banner
        InfoBanner(scFile)

        // Tabs
        ScrollableTabRow(
            selectedTabIndex = tabIdx,
            containerColor   = DarkSurface,
            contentColor     = AccentYellow,
            indicator = { positions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(positions[tabIdx]),
                    color = AccentYellow
                )
            }
        ) {
            tabs.forEachIndexed { i, title ->
                Tab(
                    selected = tabIdx == i,
                    onClick  = { tabIdx = i },
                    text = {
                        Text(
                            title,
                            color = if (tabIdx == i) AccentYellow else OnDarkSecondary,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                )
            }
        }

        when (tabIdx) {
            0 -> ExportsList(scFile.exports, onEditExport)
            1 -> ShapesList(scFile.shapes)
            2 -> TexturesList(scFile.textures)
            3 -> MatricesList(scFile.matrices)
            4 -> InfoTab(scFile)
        }
    }
}

@Composable
private fun InfoBanner(scFile: ScFile) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkCard)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        InfoChip("v${scFile.version}", Icons.Default.Info)
        InfoChip(scFile.compression.name, Icons.Default.Compress)
        InfoChip("${scFile.exports.size} exports", Icons.Default.PlayCircle)
        InfoChip("${scFile.textures.size} textures", Icons.Default.Image)
    }
}

@Composable
private fun InfoChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Icon(icon, null, tint = AccentBlue, modifier = Modifier.size(12.dp))
        Text(label, style = MaterialTheme.typography.bodySmall, color = OnDarkSecondary)
    }
}

@Composable
private fun ExportsList(exports: List<Export>, onEdit: (Int) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        itemsIndexed(exports) { _, exp ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkCard)
                    .clickable { onEdit(exp.id) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Animation, null, tint = AccentYellow,
                    modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(exp.name, color = OnDark, style = MaterialTheme.typography.titleMedium)
                    Text("ID: ${exp.id}  |  Movieclip: ${exp.movieclipId}",
                        style = MaterialTheme.typography.bodySmall, color = OnDarkSecondary)
                }
                Icon(Icons.Default.Edit, null, tint = AccentBlue, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun ShapesList(shapes: List<Shape>) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(shapes) { _, shape ->
            ListItem(
                headlineContent = { Text("Shape #${shape.id}", color = OnDark) },
                supportingContent = { Text("${shape.chunks.size} chunks",
                    style = MaterialTheme.typography.bodySmall, color = OnDarkSecondary) },
                leadingContent = {
                    Icon(Icons.Default.Layers, null, tint = AccentBlue)
                },
                colors = ListItemDefaults.colors(containerColor = DarkCard),
                modifier = Modifier.clip(RoundedCornerShape(10.dp))
            )
        }
    }
}

@Composable
private fun TexturesList(textures: List<ScTexture>) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(textures) { _, tex ->
            ListItem(
                headlineContent = { Text("Texture #${tex.index}", color = OnDark) },
                supportingContent = {
                    Text("${tex.width}×${tex.height}  ${tex.pixelFormat.name}",
                        style = MaterialTheme.typography.bodySmall, color = OnDarkSecondary)
                },
                leadingContent = {
                    Icon(Icons.Default.Image, null, tint = AccentYellow)
                },
                colors = ListItemDefaults.colors(containerColor = DarkCard),
                modifier = Modifier.clip(RoundedCornerShape(10.dp))
            )
        }
    }
}

@Composable
private fun MatricesList(matrices: List<Matrix>) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(matrices) { _, m ->
            ListItem(
                headlineContent = { Text("Matrix #${m.id}", color = OnDark) },
                supportingContent = {
                    Text("[%.2f, %.2f, %.2f, %.2f] tx=%.1f ty=%.1f"
                        .format(m.a, m.b, m.c, m.d, m.tx, m.ty),
                        style = MaterialTheme.typography.bodySmall, color = OnDarkSecondary)
                },
                leadingContent = {
                    Icon(Icons.Default.Transform, null, tint = AccentBlue)
                },
                colors = ListItemDefaults.colors(containerColor = DarkCard),
                modifier = Modifier.clip(RoundedCornerShape(10.dp))
            )
        }
    }
}

@Composable
private fun InfoTab(scFile: ScFile) {
    val rows = listOf(
        "Version"     to "v${scFile.version}",
        "Compression" to scFile.compression.name,
        "Exports"     to scFile.exports.size.toString(),
        "Movieclips"  to scFile.movieclips.size.toString(),
        "Shapes"      to scFile.shapes.size.toString(),
        "Textures"    to scFile.textures.size.toString(),
        "Matrices"    to scFile.matrices.size.toString(),
        "ColorSpaces" to scFile.colorSpaces.size.toString(),
        "TextFields"  to scFile.textFields.size.toString()
    )
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        itemsIndexed(rows) { _, (label, value) ->
            Row(
                modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkCard)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(label, color = OnDarkSecondary, style = MaterialTheme.typography.bodySmall)
                Text(value, color = AccentYellow, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun LoadingView(modifier: Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = AccentYellow)
    }
}

@Composable
private fun ErrorView(msg: String, modifier: Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.ErrorOutline, null, tint = AccentRed,
                modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(8.dp))
            Text("Failed to parse file", color = AccentRed)
            Text(msg, color = OnDarkSecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}
