package com.sceditor.ui.screens.editor

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sceditor.data.model.*
import com.sceditor.data.repository.ScRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class EditorState(
    val scFile: ScFile? = null,
    val export: Export? = null,
    val movieclip: Movieclip? = null,
    val selectedFrameIndex: Int = 0,
    val selectedElementIndex: Int = -1,
    val isLoading: Boolean = false,
    val error: String? = null,
    val isSaved: Boolean = false
)

@HiltViewModel
class EditorViewModel @Inject constructor(
    private val repo: ScRepository
) : ViewModel() {

    private val _state = MutableStateFlow(EditorState())
    val state = _state.asStateFlow()

    private var fileUri: String = ""

    fun load(uriString: String, exportId: Int) {
        fileUri = uriString
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true)
            repo.openFile(Uri.parse(uriString))
                .onSuccess { scFile ->
                    val export    = scFile.exports.find { it.id == exportId }
                    val movieclip = scFile.movieclips.find { it.id == export?.movieclipId }
                    _state.value = _state.value.copy(
                        scFile    = scFile,
                        export    = export,
                        movieclip = movieclip,
                        isLoading = false
                    )
                }
                .onFailure {
                    _state.value = _state.value.copy(isLoading = false, error = it.message)
                }
        }
    }

    fun selectFrame(index: Int) {
        _state.value = _state.value.copy(selectedFrameIndex = index, selectedElementIndex = -1)
    }

    fun selectElement(index: Int) {
        _state.value = _state.value.copy(selectedElementIndex = index)
    }

    /** Move selected element's shape chunk by (dx, dy) by generating a new matrix */
    fun moveElement(dx: Float, dy: Float) {
        val s         = _state.value
        val scFile    = s.scFile ?: return
        val mc        = s.movieclip ?: return
        val frameIdx  = s.selectedFrameIndex
        val elemIdx   = s.selectedElementIndex
        if (elemIdx < 0) return

        val frame   = mc.frames[frameIdx]
        val element = frame.elements[elemIdx]

        // Add a new translation matrix
        val newMatrix = Matrix(
            id = scFile.matrices.size,
            a = 1f, b = 0f, c = 0f, d = 1f,
            tx = dx, ty = dy
        )
        val newMatrices = scFile.matrices + newMatrix
        val newElement  = element.copy(matrixIndex = newMatrix.id)
        val newElements = frame.elements.toMutableList().apply { set(elemIdx, newElement) }
        val newFrame    = frame.copy(elements = newElements)
        val newFrames   = mc.frames.toMutableList().apply { set(frameIdx, newFrame) }
        val newMc       = mc.copy(frames = newFrames)
        val newMcs      = scFile.movieclips.toMutableList().apply {
            val idx = indexOfFirst { it.id == mc.id }
            if (idx >= 0) set(idx, newMc)
        }
        val newScFile = scFile.copy(matrices = newMatrices, movieclips = newMcs)
        _state.value = s.copy(scFile = newScFile, movieclip = newMc)
    }

    /** Add a new empty frame to the current movieclip */
    fun addFrame(name: String = "frame_${System.currentTimeMillis()}") {
        val s      = _state.value
        val scFile = s.scFile ?: return
        val mc     = s.movieclip ?: return
        val newFrames = mc.frames.toMutableList().apply { add(MovieclipFrame(name)) }
        val newMc     = mc.copy(frames = newFrames)
        updateMovieclip(scFile, newMc)
    }

    /** Remove the selected frame */
    fun removeFrame() {
        val s      = _state.value
        val scFile = s.scFile ?: return
        val mc     = s.movieclip ?: return
        if (mc.frames.isEmpty()) return
        val newFrames = mc.frames.toMutableList().apply { removeAt(s.selectedFrameIndex) }
        val newMc     = mc.copy(frames = newFrames)
        updateMovieclip(scFile, newMc)
        _state.value = _state.value.copy(selectedFrameIndex = 0)
    }

    /** Clone the current export as a new export */
    fun cloneExport() {
        val s      = _state.value
        val scFile = s.scFile ?: return
        val export = s.export ?: return
        val mc     = s.movieclip ?: return

        val newMcId     = (scFile.movieclips.maxOfOrNull { it.id } ?: 0) + 1
        val newExportId = (scFile.exports.maxOfOrNull { it.id } ?: 0) + 1

        val newMc     = mc.copy(id = newMcId)
        val newExport = export.copy(id = newExportId, name = "${export.name}_clone",
            movieclipId = newMcId)

        val newScFile = scFile.copy(
            exports    = scFile.exports + newExport,
            movieclips = scFile.movieclips + newMc
        )
        _state.value = s.copy(scFile = newScFile)
    }

    fun saveToUri(uriString: String) {
        val scFile = _state.value.scFile ?: return
        viewModelScope.launch {
            repo.saveFile(scFile, Uri.parse(uriString))
                .onSuccess { _state.value = _state.value.copy(isSaved = true) }
                .onFailure { _state.value = _state.value.copy(error = it.message) }
        }
    }

    private fun updateMovieclip(scFile: ScFile, newMc: Movieclip) {
        val newMcs = scFile.movieclips.toMutableList().apply {
            val idx = indexOfFirst { it.id == newMc.id }
            if (idx >= 0) set(idx, newMc)
        }
        val newScFile = scFile.copy(movieclips = newMcs)
        _state.value = _state.value.copy(scFile = newScFile, movieclip = newMc)
    }
}
